> 本软件采用 AGPL-3.0 许可证，同时**禁止任何第三方以直接售卖、付费下载、订阅服务等方式盈利**。  
> 允许自由使用、修改和分发，但不得以本软件本身作为商品进行交易。

# Typecho 60秒日报插件使用教程

## 🚀 插件功能

- 自动获取"60秒读懂世界"每日新闻简报
- 自动发布到指定Typecho分类
- 支持本地/远程图片切换
- 自动添加日期和星期信息
- 包含精美的提示框样式

## 📦 安装步骤

### 1. 上传文件
将 `60s.zip` 文件上传到您的Typecho网站根目录解压：
```text
/您的网站根目录/
├── 60s.zip          ← 解压后删除
├── 60s.php          ← 上传到这里
├── usr/uploads/60s/
└── ...其他Typecho文件
```

## ⚙️ 配置说明

打开 `60s.php` 修改以下参数：

```php
// 基本配置
$categoryName = '新闻早报'; // ← 修改为您的分类名称
$useRemoteImage = false;   // true=使用API图片 false=使用本地图片

// 本地图片配置
$localImageBasePath = '/usr/uploads/60s/'; // 本地图片路径

// 文章标题配置
$title = $date. '，每日 60 秒读懂世界'; // $date变量包含日期信息

// 内容样式配置（可直接修改样式）
$content = '<div style="text-align: center;...">💡每天一分钟...</div>';
```

## 🕒 定时任务设置（推荐）

添加Cron任务实现每日自动发布：

```bash
# 每天上午8点执行
0 8 * * * /usr/bin/php /网站路径/60s.php >/dev/null 2>&1
```
添加宝塔定时任务实现每日自动发布：
![btds.jpg](https://blog.xoun.cn/usr/uploads/2025/05/3373247637.jpg)
看图，按图里的来
## 🖥️ 手动执行方式

1. 通过浏览器访问：
   ```text
   http://您的域名/60s.php
   ```
2. 通过命令行执行：
   ```bash
   php /网站路径/60s.php
   ```

## 🔍 常见问题

### Q1: 如何查找分类ID？
- 登录Typecho后台
- 进入"分类"管理页面
- 查看分类对应的名称（也就是你自己设置的）

### Q2: 图片不显示怎么办？
- 检查图片路径是否正确
- 确保图片有读取权限
- 可暂时切换为远程图片测试
```php
(`$useRemoteImage = true`)
```
### Q3: 如何修改内容样式？
直接编辑文件中的HTML和CSS样式：
```php
// 顶部提示框样式
'<div style="text-align: center; font-size: 16px;...">'

// 底部提示框样式
'<div style="text-align: center; font-size: 16px;...">'
```

## 💡 高级设置

1. **修改API源**：
   ```php
   $apiUrl = 'http://api.suxun.site/api/sixs?type=json';
   ```

2. **修改发布状态**：
   ```php
   'status' => 'publish', // 改为'draft'可存为草稿
   ```

3. **关闭评论**：
   ```php
   'allowComment' => 0,
   ```

## 📝 注意事项

1. 首次使用建议先设置为草稿模式测试
2. 确保服务器有访问外部API的权限
3. 修改文件前建议备份
4. 如遇编码问题，检查数据库是否为utf8mb4

> 提示：插件默认会在文章顶部和底部各添加一个美观的提示框，您可以根据需要修改或删除这些内容。